%______________________________________________________________________________
%
% Copyright (C) 2021 Francois G. Meyer <FMeyer@Colorado.Edu>
%
% All rights reserved.
%
% Redistribution and use in source and binary forms, with or without
% modification, are permitted provided that the following conditions are met:
% 
%   a. Redistributions of source code must retain the above copyright notice,
%      this list of conditions and the following disclaimer.
% 
%   b. Redistributions in binary form must reproduce the above copyright
%      notice, this list of conditions and the following disclaimer in the
%      documentation and/or other materials provided with the distribution.
% 
%   c. Neither the name of the copyright holders nor the names of any
%      contributors to this software may be used to endorse or promote products
%      derived from this software without specific prior written permission.
% 
% 
% THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS on an
% "AS IS" basis. THE COPYRIGHT HOLDERS AND CONTRIBUTORS MAKE NO
% REPRESENTATIONS OR WARRANTIES, EXPRESS OR IMPLIED.  BY WAY OF EXAMPLE, BUT
% NOT LIMITATION, THE COPYRIGHT HOLDERS AND CONTRIBUTORS MAKE NO AND
% DISCLAIMS ANY REPRESENTATION OR WARRANTY OF MERCHANTABILITY OR FITNESS FOR
% ANY PARTICULAR PURPOSE OR THAT THE USE OF THIS SOFTWARE WILL NOT INFRINGE
% ANY THIRD PARTY RIGHTS.
% 
% THE COPYRIGHT HOLDERS AND CONTRIBUTORS SHALL NOT BE LIABLE TO LICENSEE OR
% ANY OTHER USERS OF THIS SOFTWARE FOR ANY INCIDENTAL, SPECIAL, OR
% CONSEQUENTIAL DAMAGES OR LOSS AS A RESULT OF MODIFYING, DISTRIBUTING, OR
% OTHERWISE USING THIS SOFTWARE, OR ANY DERIVATIVE THEREOF, EVEN IF ADVISED
% OF THE POSSIBILITY THEREOF.
%
%
%_Module_Name : sharpthreshold
%
%_Description : 
%
% This script is designed to validate Theorem 1: for a fixed large sample size, 
% we compute the median and mean for a range of p_ij sampled from a beta distribution (A,B), 
% where the mean A/(A+B) goes from 0 to 1. We demonstrate the phase transition, as the mean 
% of the beta distribution passes at 1/2.
%
% The script runs the function validateMedian
%
%_References : The Fréchet Mean of Inhomogeneous Random Graphs, François G. Meyer, 2021.
%
%_Remarks : We parameterize the beta (A,B), with C = A+B and A. For a given C, A ranges from 0 to C, 
%           so that the mean = A/C = A/(A+B) goes from 0 to 1.
%
%_Author :                 Francois G. Meyer
%
%_Revisions History: 2021 Initial keying
%
%______________________________________________________________________________
%

C = 64;                                 % beta prior: C = A + B, we move A below.
                                                                                                      
nValues = 40;                           % how many values of the parameters within the range of the beta prior
deltaA  = C/(nValues+1);

maxTrials = 16;                         % number of experiments for a fixed sample size               
                                        % 64 is OK, we used 50 in the PLOS paper.
nBsamples = 16;                         % number of random samples for the B matrix in validateMedian

nVertices = 64;                         % graph size                                                  

N = 1000;                              % size of the graph sample

F    = zeros (5, nValues);
smpl = zeros (1, nValues);

fzero = zeros (5, maxTrials);

histH = zeros (maxTrials, nValues);

%
% beta prior for the matrices P generated in validateMean


fprintf ('\n');
lastsize = 0;

for nF=1:nValues                        % for every beta distribution located from 1 to C*(1 -1/nValues)
    
    A = nF*deltaA;                      % increment A
    B = C -A;                           % compute the corresponding B

    % generate the 4 values for several random realizations of the N random graphs
    
    fzero(:) = 0;

    for ntrials=1:maxTrials
        fzero (:, ntrials) =  validateMedian (nVertices,N, A, B, nBsamples);
    end

    fzero = 2* fzero ./(nVertices * (nVertices-1));
    
    histH (:,nF) = abs(fzero (5,:))';
    
    % save the mean of the volume of median graph
    
    F(:,nF)  = mean(fzero,2);
    
    % save the expectation
    
    smpl (nF) = A/C;

    fprintf(repmat('\b', 1, lastsize));
    lastsize = fprintf('%2d',nF);
end

% F(1) = theoretical Frechet function at the theoretical median
% F(2) = sample Frechet function at the sample median
% F(3) = hamming distance (population graph median, sample graph median)
% F(4) = population function - sample function at some random graphs


% fit a fifth order polynomial, and compute the values of the polynomial

coeff5   = polyfit (smpl, F(5,:),13);    

linereg5 = polyval(coeff5, smpl)';

%
% figure : volume of the frechet median
%

xlabels = num2str(smpl',' %.2f'); 

f = figure;f.Position = [2000 1000 1000 1000];

p2 = plot ([1:nValues],linereg5,'blue'); 

set (gca,'FontSize',20);
set (gca,'FontName','Helvetica');

hold on;

set(findobj(gca,'Type','text'),'FontSize',20,'rotation',90)

set(p2,'LineWidth',1.25);

axis tight

set(get(gca, 'XLabel'),...
    'String','$E[p]$','Interpreter','latex',...
    'FontName','Times','FontSize',32, 'LineWidth',1.25);

set(get(gca, 'YLabel'),...
    'String','$2 \left | \mathcal{E} (\widehat{I \mkern -6mu E}_N[\boldmath{A}]) \right |/(n(n-1)$','Interpreter','latex',...
    'FontName','Times','FontSize',32, 'LineWidth',1.25);

set (get(gca,'XAxis'), 'LineWidth', 2,'TickLength',[0.01 0.01]);
set (get(gca,'YAxis'), 'LineWidth', 2,'TickLength',[0.01 0.01]);

p1 = boxplot((abs(histH)),smpl,'Labels', xlabels,'PlotStyle','compact','BoxStyle','outline','colors',[1 0 0]);
set(p1,'LineWidth',1.25);

set(gca,'xtick',1:length(xlabels));

xticklabels (xlabels);

print -depsc 'theorem1-median.eps'

keyboard;