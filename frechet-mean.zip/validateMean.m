%______________________________________________________________________________
%
% Copyright (C) 2021 Francois G. Meyer <FMeyer@Colorado.Edu>
%
% All rights reserved.
%
% Redistribution and use in source and binary forms, with or without
% modification, are permitted provided that the following conditions are met:
% 
%   a. Redistributions of source code must retain the above copyright notice,
%      this list of conditions and the following disclaimer.
% 
%   b. Redistributions in binary form must reproduce the above copyright
%      notice, this list of conditions and the following disclaimer in the
%      documentation and/or other materials provided with the distribution.
% 
%   c. Neither the name of the copyright holders nor the names of any
%      contributors to this software may be used to endorse or promote products
%      derived from this software without specific prior written permission.
% 
% 
% THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS on an
% "AS IS" basis. THE COPYRIGHT HOLDERS AND CONTRIBUTORS MAKE NO
% REPRESENTATIONS OR WARRANTIES, EXPRESS OR IMPLIED.  BY WAY OF EXAMPLE, BUT
% NOT LIMITATION, THE COPYRIGHT HOLDERS AND CONTRIBUTORS MAKE NO AND
% DISCLAIMS ANY REPRESENTATION OR WARRANTY OF MERCHANTABILITY OR FITNESS FOR
% ANY PARTICULAR PURPOSE OR THAT THE USE OF THIS SOFTWARE WILL NOT INFRINGE
% ANY THIRD PARTY RIGHTS.
% 
% THE COPYRIGHT HOLDERS AND CONTRIBUTORS SHALL NOT BE LIABLE TO LICENSEE OR
% ANY OTHER USERS OF THIS SOFTWARE FOR ANY INCIDENTAL, SPECIAL, OR
% CONSEQUENTIAL DAMAGES OR LOSS AS A RESULT OF MODIFYING, DISTRIBUTING, OR
% OTHERWISE USING THIS SOFTWARE, OR ANY DERIVATIVE THEREOF, EVEN IF ADVISED
% OF THE POSSIBILITY THEREOF.
%
%
%_Module_Name : validateMean
%
%_Description :  Generate N graphs from an inhomogeneous model: each edge is a Bernoulli Be(p_ij). We use different prior for
%                the matrix P = [p_ij]:
%                 - uniform distribution U[0,1]
%                 - beta distribution B(A,B)
% 
%                nBsamples =  number of graphs B at which we evaluate the two flavors of the Frechet function
%
%                1) evaluate the convergence of the Frechet function as the number of samples N --> infty, for a fixed graph B
%                2) evaluate the convergence of the sample graph mean toward the population mean. We use the Hamming distance
%                to measure  the distance between the two graphs
%
%_References :
%
%_Remarks : None
%
%_Author :                 Francois G. Meyer
%
%_Revisions History: 2021 Initial keying
%
%______________________________________________________________________________

function [F] = validateMean (nVertices, N, A, B, nBsamples)

DEMO = 0;                               % no display

% maximum number of edges

M =  nVertices*(nVertices -1)/2;

% construct the probability matrix P

P = zeros (nVertices, nVertices);

% the top triangle is populated with a prior
%
% uniform prior: 
% topP = rand (M,1);
%
% beta prior

topP = betarnd(A,B,M,1);

P (tril(true(nVertices),-1)) = topP;
P = P';
P (tril(true(nVertices),-1)) = topP;

% allocate memory for  N random graphs and their respective probabilities

AkN = zeros (N, nVertices, nVertices);

% allocate some memory for the Frechet function

F = zeros (5,1);

% build and store N random graphs

for k = 1:N

    AkN(k, :, :) = IHfast (P);

end

% compute the median graph 

medA = mediangraph (AkN);

% compute the population median

ifA  = (P >= 0.5*ones(nVertices,nVertices));
fA   = zeros (nVertices,nVertices);
fA(ifA) = 1;
 
% theoretical Frechet function at the theoretical mean

fAPop   = meanPopulation(P,fA);

% sample Frechet function at the sample mean

medSamp = meanFast (AkN, medA);

% Hamming distance between the sample Frechet mean and population Frechet mean

dH = dhamming(fA,medA);

% compare the sample Frechet function to the population Frechet function, both evaluated at a graph B. We randomly choose the
% graph, using the same prior probability P.

dF = 0;

fprintf ('\n');

for nB = 1:nBsamples

    B  = IHfast (P);                    % select an inhomogeneous  random graph 
    f1 = meanPopulation(P,B);           % population frechet function at B
    f2 = meanFast (AkN, B);             % sample Frechet function at B
    dF = dF + abs(f1-f2);               % difference between the population and sample Frechet functions

    fprintf ('-');
end

dF = dF /nBsamples;                         % normalize the difference                                         

F(1,1) = fAPop;
F(2,1) = medSamp;
F(3,1) = dH;
F(4,1) = dF;
F(5,1) = 0.5*sum (medA,'all');          % volume of the median graph


if (DEMO)
    fprintf ('\n\t population frechet function at the population mean = %f', fAPop);
    fprintf ('\n\t sample frechet function at the sample median = %f', medSamp);
    fprintf('\n\t relative difference (population - sample) : %9.5e', (fAPop - medSamp)/fAPop);

    fprintf ('\n\t Hamming distance between the sample and population means = %f', dH);
    fprintf('\n\t difference (population - sample) at some random graphs: %9.5e', dF);
    
    fprintf("\n\n");

    figure;imagesc(medA);title ('sample'); colorbar;

    figure;imagesc(fA);title ('population'); colorbar;

    figure;imagesc(medA-fA);title ('difference'); colorbar;
end
    
end