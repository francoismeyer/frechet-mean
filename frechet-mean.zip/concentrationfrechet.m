%______________________________________________________________________________
%
% Copyright (C) 2021 Francois G. Meyer <FMeyer@Colorado.Edu>
%
% All rights reserved.
%
% Redistribution and use in source and binary forms, with or without
% modification, are permitted provided that the following conditions are met:
% 
%   a. Redistributions of source code must retain the above copyright notice,
%      this list of conditions and the following disclaimer.
% 
%   b. Redistributions in binary form must reproduce the above copyright
%      notice, this list of conditions and the following disclaimer in the
%      documentation and/or other materials provided with the distribution.
% 
%   c. Neither the name of the copyright holders nor the names of any
%      contributors to this software may be used to endorse or promote products
%      derived from this software without specific prior written permission.
% 
% 
% THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS on an
% "AS IS" basis. THE COPYRIGHT HOLDERS AND CONTRIBUTORS MAKE NO
% REPRESENTATIONS OR WARRANTIES, EXPRESS OR IMPLIED.  BY WAY OF EXAMPLE, BUT
% NOT LIMITATION, THE COPYRIGHT HOLDERS AND CONTRIBUTORS MAKE NO AND
% DISCLAIMS ANY REPRESENTATION OR WARRANTY OF MERCHANTABILITY OR FITNESS FOR
% ANY PARTICULAR PURPOSE OR THAT THE USE OF THIS SOFTWARE WILL NOT INFRINGE
% ANY THIRD PARTY RIGHTS.
% 
% THE COPYRIGHT HOLDERS AND CONTRIBUTORS SHALL NOT BE LIABLE TO LICENSEE OR
% ANY OTHER USERS OF THIS SOFTWARE FOR ANY INCIDENTAL, SPECIAL, OR
% CONSEQUENTIAL DAMAGES OR LOSS AS A RESULT OF MODIFYING, DISTRIBUTING, OR
% OTHERWISE USING THIS SOFTWARE, OR ANY DERIVATIVE THEREOF, EVEN IF ADVISED
% OF THE POSSIBILITY THEREOF.
%
%
%_Module_Name : concentration-frechet
%
%_Description :  Script used to generate the figures in the paper
% 
% This script is designed to validate Lemma 6 and Theorem 2: concentration of the Frechet function for the mean, as the number
% of samples N --> infinity
%
% We compute not just one, but in fact several errors for different P matrices.
%
% run the function validateMean.m for a range of sample size, and graph sizes
%
%
%_References :
%
%_Remarks : None
%
%_Author :                 Francois G. Meyer
%
%_Revisions History: 2021 Initial keying
%
%______________________________________________________________________________
% 
%
%

%
% range of sample size = [n0,n1]
%

n0 = 10;
n1 = 1e4;                               % range of sample size

nValues = 20;                           % how many values of the sample size within the range

maxTrials = 16;                         % number of experiments for a fixed sample size
nBsamples = 16;                         % number of random samples for the B matrix in validateMedian

nVertices = 512;                        % graph size                                                  

A = 2;                                  % beta prior for the matrices P generated in validateMean
B = 10;


logq = log(n1/n0)/nValues;              % we use a log scale for the sample size

F    = zeros (5, nValues);
smpl = zeros (1, nValues);

fzero= zeros (5, maxTrials);

histB = zeros (maxTrials, nValues);
histF = zeros (maxTrials, nValues);
histH = zeros (maxTrials, nValues);


fprintf ('\n');
lastsize = 0;

for nF=1:nValues
    

    Nf = n0*exp((nF-1)*logq);

    N = round (Nf);
    
    fzero(:) = 0;
    for ntrials=1:maxTrials
        fzero (:, ntrials) =  validateMean   (nVertices,N, A, B, nBsamples);
    end
    
    histF (:,nF) = (abs(fzero (2,:) -fzero(1,:)))';
    histH (:,nF) = abs(fzero (3,:))';
    histB (:,nF) = abs(fzero (4,:))';
    
    % save the mean and the std of the 4 estimates of the Frechet function
    
    F(:,nF)  = mean(fzero,2);
    
    % save the sample size
    
    smpl (nF) = Nf;
    
    fprintf(repmat('\b', 1, lastsize));
    lastsize = fprintf('%2d',nF);
end

% F(1) = theoretical Frechet function at the theoretical median
% F(2) = sample Frechet function at the sample median
% F(3) = hamming distance (population graph median, sample graph median)
% F(4) = population function - sample function at some random graphs


coeff12   = polyfit (log(smpl),log (abs(F(2,:) -F(1,:))),1)
linereg12 = polyval(coeff12,log(smpl))';

coeff3   = polyfit (log(smpl),log (abs(F(3,:))),1)
linereg3 = polyval(coeff3,log(smpl))';

coeff4   = polyfit (log(smpl),log (abs(F(4,:))),1)
linereg4 = polyval(coeff4,log(smpl))';

%
% figure 1: theoretical Frechet function (theoretical median) - sample Frechet function(sample median)
%

f = figure;f.Position = [2000 1000 1000 1000];

p2 = plot ([1:nValues],linereg12,'blue'); 
xlabels = num2str(smpl',' %.0f'); xticklabels (xlabels);

set (gca,'FontSize',20);
set (gca,'FontName','Helvetica');
hold on;

set(findobj(gca,'Type','text'),'FontSize',20,'rotation',30)

set(p2,'LineWidth',1.25);

axis tight

set(get(gca, 'XLabel'),...
    'String','$N$','Interpreter','latex',...
    'FontName','Times','FontSize',32, 'LineWidth',1.25);

set(get(gca, 'YLabel'),...
    'String','$\log \left ( F_2 (E[\boldmath{A}]) -\widehat{F}_2(\widehat{I \mkern -6mu E}_N[\boldmath{A}])\right)$','Interpreter','latex',...
    'FontName','Times','FontSize',32, 'LineWidth',1.25);

set (get(gca,'XAxis'), 'LineWidth', 2,'TickLength',[0.01 0.01]);
set (get(gca,'YAxis'), 'LineWidth', 2,'TickLength',[0.01 0.01]);

p1 = boxplot(log(abs(histF)),smpl,'Labels', xlabels,'PlotStyle','compact','BoxStyle','outline','colors',[1 0 0]);

set(p1,'LineWidth',1.25);

set(gca,'xtick',1:length(xlabels));

xticklabels (xlabels);

print -depsc 'f1hat_sample-f1theory_theo-mean.eps'

%
%
% figure 2: hamming distance (population graph median, sample graph median)
%

f = figure;f.Position = [2000 1000 1000 1000];

p2 = plot ([1:nValues],linereg3,'blue'); 
xticklabels (xlabels);

set (gca,'FontSize',20);
set (gca,'FontName','Helvetica');

hold on;

set(findobj(gca,'Type','text'),'FontSize',20,'rotation',30)

set(p2,'LineWidth',1.25);

axis tight

set(get(gca, 'XLabel'),...
    'String','$N$','Interpreter','latex',...
    'FontName','Times','FontSize',32, 'LineWidth',1.25);

set(get(gca, 'YLabel'),...
    'String','$\log\left(d_H (E[\boldmath{A}],\widehat{I \mkern -6mu E}_N[\boldmath{A}]) \right)$','Interpreter','latex',...
    'FontName','Times','FontSize',32, 'LineWidth',1.25);

set (get(gca,'XAxis'), 'LineWidth', 2,'TickLength',[0.01 0.01]);
set (get(gca,'YAxis'), 'LineWidth', 2,'TickLength',[0.01 0.01]);

p1 = boxplot(log(abs(histH)),smpl,'Labels', xlabels,'PlotStyle','compact','BoxStyle','outline','colors',[1 0 0]);

set(p1,'LineWidth',1.25);

set(gca,'xtick',1:length(xlabels));

xticklabels (xlabels);

print -depsc 'dH_sample_graph_mean-sample_theo_mean.eps'

%
%
% figure 3: expected value computed at some random graphs (population function - sample function)
%

f = figure;f.Position = [2000 1000 1000 1000];

p2 = plot ([1:nValues],linereg4,'blue'); 
xticklabels (xlabels);

set (gca,'FontSize',20);
set (gca,'FontName','Helvetica');

hold on;

set(findobj(gca,'Type','text'),'FontSize',20,'rotation',30)

set(p2,'LineWidth',1.25);

axis tight

set(get(gca, 'XLabel'),...
    'String','$N$','Interpreter','latex',...
    'FontName','Times','FontSize',32, 'LineWidth',1.25);

set(get(gca, 'YLabel'),...
    'String',...
    '$\log \left(\widehat{I \mkern -6mu E}_{N_B} \left [F_2(\boldmath{B}]) - \widehat{F_2}(\boldmath{B})\right]\right)$',...
    'Interpreter','latex',...
    'FontName','Times','FontSize',32, 'LineWidth',1.25);

set (get(gca,'XAxis'), 'LineWidth', 2,'TickLength',[0.01 0.01]);
set (get(gca,'YAxis'), 'LineWidth', 2,'TickLength',[0.01 0.01]);

p1 = boxplot(log(abs(histB)),smpl,'Labels', xlabels,'PlotStyle','compact','BoxStyle','outline','colors',[1 0 0]);

set(p1,'LineWidth',1.25);

set(gca,'xtick',1:length(xlabels));

xticklabels (xlabels);

print -depsc 'fE_sample_frechet_mean-theo_frechet_mean.eps'

keyboard;

