%______________________________________________________________________________
%
% Copyright (C) 2021 Francois G. Meyer <FMeyer@Colorado.Edu>
%
% All rights reserved.
%
% Redistribution and use in source and binary forms, with or without
% modification, are permitted provided that the following conditions are met:
% 
%   a. Redistributions of source code must retain the above copyright notice,
%      this list of conditions and the following disclaimer.
% 
%   b. Redistributions in binary form must reproduce the above copyright
%      notice, this list of conditions and the following disclaimer in the
%      documentation and/or other materials provided with the distribution.
% 
%   c. Neither the name of the copyright holders nor the names of any
%      contributors to this software may be used to endorse or promote products
%      derived from this software without specific prior written permission.
% 
% 
% THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS on an
% "AS IS" basis. THE COPYRIGHT HOLDERS AND CONTRIBUTORS MAKE NO
% REPRESENTATIONS OR WARRANTIES, EXPRESS OR IMPLIED.  BY WAY OF EXAMPLE, BUT
% NOT LIMITATION, THE COPYRIGHT HOLDERS AND CONTRIBUTORS MAKE NO AND
% DISCLAIMS ANY REPRESENTATION OR WARRANTY OF MERCHANTABILITY OR FITNESS FOR
% ANY PARTICULAR PURPOSE OR THAT THE USE OF THIS SOFTWARE WILL NOT INFRINGE
% ANY THIRD PARTY RIGHTS.
% 
% THE COPYRIGHT HOLDERS AND CONTRIBUTORS SHALL NOT BE LIABLE TO LICENSEE OR
% ANY OTHER USERS OF THIS SOFTWARE FOR ANY INCIDENTAL, SPECIAL, OR
% CONSEQUENTIAL DAMAGES OR LOSS AS A RESULT OF MODIFYING, DISTRIBUTING, OR
% OTHERWISE USING THIS SOFTWARE, OR ANY DERIVATIVE THEREOF, EVEN IF ADVISED
% OF THE POSSIBILITY THEREOF.
%
%
%_Module_Name : meanFast
%
%_Description : compute the Frechet function: sum of the Hamming distances squared between the matrix B and the N matrices
%               in AkN. 
%_References :
%
%_Remarks : we use the fast method, where everything is linearized: 10 times faster.
%
%_Author :                 Francois G. Meyer
%
%_Revisions History: 2021 Initial keying
%
%______________________________________________________________________________
function [f] = meanFast (AkN, B)

%
%
    
nGraphs = size(AkN,1);
sizeA       = size (AkN,2);

A = reshape(AkN, nGraphs, sizeA* sizeA);

ipos = find (B > 0);
ineg = find (B == 0);

a = sum(sum(A,2).^2, 1);

b = 2*length(ipos)* (sum (A(:,ineg),'all') - sum(A(:,ipos),'all'));

c = nGraphs * length(ipos)*length(ipos);

d = 4*sum(sum(A(:,ineg),2) .* sum(A(:,ipos),2));

d = a + b + c - d;

% normalize: divide by the number of graphs, 
% also divide the Hamming distance by 2, 
% so divide the Hamming distance squared by 4

f= d/(4 * nGraphs);

end